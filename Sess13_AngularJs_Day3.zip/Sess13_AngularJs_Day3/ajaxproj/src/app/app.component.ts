import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  task = new FormControl();
  title = 'bootstrap practice';
  taskPlaceholder = 'Enter Task Here';
  btnTitle = 'Add Task';

  taskList = [];
  addTask() {
    const newTask = this.task.value;
    this.taskList.push(newTask);
  }
}
