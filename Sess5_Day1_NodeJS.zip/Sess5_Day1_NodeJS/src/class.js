class Person{
    constructor() { 
        console.log("I Am Constuctor")
    }

    getPersonName() { 
        return 'Shruti Jamdade';
    }

    static main() {
        let obj = new Person();
        const name = obj.getPersonName();
        console.log(name);
    }
}

Person.main();