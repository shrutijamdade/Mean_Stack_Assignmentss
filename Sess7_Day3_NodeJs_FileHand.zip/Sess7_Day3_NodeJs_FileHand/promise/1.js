const fs = require("fs");

const Promise = require("bluebird");
Promise.promisifyAll(fs); // Promisification of FS Module

let readDemo = () => {
  // fs.readFile();

  const filePath1 = "G:/CDAC/Mean_Stack/abc.txt";
  // fs.readFileAsync(filePath1, { encoding: "utf-8" });
  fs.readFileAsync(filePath1, { encoding: "utf-8" })
    .then((data) => {
      // file 1 done
      console.log(data);

      const filePath2 = "G:/CDAC/Mean_Stack/abc.txt";
      return fs.readFileAsync(filePath2, { encoding: "utf-8" });
    })
    .then((data) => {
      // file 2 done
      console.log(data);

      const filePath3 = "G:/CDAC/Mean_Stack/abc.txt";
      return fs.readFileAsync(filePath3, { encoding: "utf-8" });
    })
    .then((data) => {
      // file 3 done
      console.log(data);
    });
};

readDemo();