// Read Again
const fs = require("fs");

let readDemo = () => {
  const filePath = "G:/CDAC/Mean_Stack/abc.txt";

  fs.readFile(filePath, { encoding: "utf-8" }, (err, data) => {
    console.log(data);
  });
};

/**
 * Difficult to Understand the FLOW :: NON BLOCKING.
 * Excption Handling Becomes Difficult.
 *
 * Callback inside Callback
 */
let readDemo1 = () => {
  try {
    const filePath1 = "G:/CDAC/Mean_Stack/abc.txt";

    fs.readFile(filePath1, { encoding: "utf-8" }, (err, data) => {
      //console.log(err);
      console.log(data);
    });
  } catch (err) {
    console.log(err);
  }
};

readDemo();
readDemo1();
