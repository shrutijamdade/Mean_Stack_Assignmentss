let callAjaxUsingJquery = () => {
    let url = "http://localhost:5600/";
  
    $.ajax(url).done((data1) => {
      myDOMOperationHere(data1);
    });
  };
  
  let myDOMOperationHere = (data1) => {
    const parent = document.querySelector("#parent");
  
    const newElement = parent.children[0].cloneNode(true);
    newElement.innerHTML = data1.name + " " + data1.main.temp_max;
  
    parent.insertBefore(newElement, parent.firstChild);
  };