const mysql = require('mysql');
const Promise = require("bluebird");
const db_con = require("./conn")

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readAllUser = async () => {
    try {
        const con = mysql.createConnection(db_con.DB_CONFIG);
    
        await con.connectAsync();

        let sql = 'SELECT * FROM STUDENT';
        let results = await con.queryAsync(sql);
        await con.endAsync();
        console.log(results);
        return results;
    } catch (err) {
        console.log(err);
    }

};

readAllUser();
