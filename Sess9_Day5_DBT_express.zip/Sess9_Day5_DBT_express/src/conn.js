const DB_CONFIG = {
    host: "localhost",
    user: "root",
    password: "",
    database: "mean",
}

module.exports = {DB_CONFIG};