  
const PI = 3.14;

const sum = function (n1, n2) {
  return n1 + n2;
};

module.exports = {
  PI,
  sum,
};