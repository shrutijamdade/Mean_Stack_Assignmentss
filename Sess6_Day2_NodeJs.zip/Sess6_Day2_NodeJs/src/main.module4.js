const APP_NAME = "HELLO_NODEJS";
const PI = 3.14159;
const OPTION = 3;

module.exports = {
  APP_NAME,
  pi: PI,
  OPTION,
};